UPDATED FULL WEBSITE + STAFF AREA

PUBLIC PAGES:
- index.html
- pricing.html
- estimate.html
- book.html
- intake.html
- contact.html

STAFF/INTERNAL PAGES:
- staff-login-demo.html
- dashboard-private.html
- appointments.html
- estimates-admin.html
- service-log.html
- repair-order.html
- customers.html
- parts.html
- payments.html

IMPORTANT PRIVACY NOTE:
GitHub Pages cannot truly password-protect pages.
The staff pages are unlisted and styled as private, but anyone with the link could access them.

For real private dashboard:
Use one of these:
1. Airtable for customer/service logs
2. Softr or Glide to make a private app from Airtable/Sheets
3. Netlify with password protection options
4. Cloudflare Access in front of your site

FORMS:
These forms are visual until connected to Netlify Forms, Formspree, Google Forms, Airtable, or Google Sheets.